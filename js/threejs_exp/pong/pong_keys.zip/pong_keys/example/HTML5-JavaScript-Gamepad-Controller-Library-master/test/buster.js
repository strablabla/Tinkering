var config = module.exports;

config['Library tests raw'] = {
	rootPath: '../',
	environment: 'node',
	tests: ['test/**/*Test.js']
};
